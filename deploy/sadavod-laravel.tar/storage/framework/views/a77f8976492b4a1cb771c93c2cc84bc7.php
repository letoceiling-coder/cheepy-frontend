<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Садовод База — каталог товаров</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Manrope', 'sans-serif'] },
                    colors: {
                        primary: { 50: '#fef7ee', 100: '#fdedd6', 200: '#f9d7ad', 300: '#f4ba78', 400: '#ee9242', 500: '#ea771e', 600: '#db5d14', 700: '#b54512', 800: '#903817', 900: '#742f16' }
                    }
                }
            }
        }
    </script>
    <style>
        .scrollbar-thin::-webkit-scrollbar { width: 6px; }
        .scrollbar-thin::-webkit-scrollbar-track { background: #f1f5f9; }
        .scrollbar-thin::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 font-sans antialiased min-h-screen">

<header class="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
    <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        <a href="/" class="text-xl font-bold text-primary-600 hover:text-primary-700 whitespace-nowrap">Садовод База</a>
        <form action="/" method="GET" class="flex-1 max-w-md hidden md:flex">
            <?php if($categorySlug): ?>
                <input type="hidden" name="category" value="<?php echo e($categorySlug); ?>">
            <?php endif; ?>
            <input type="search" name="q" placeholder="Поиск по каталогу..."
                class="w-full border border-slate-200 rounded-l-lg px-3 py-2 text-sm focus:outline-none focus:border-primary-400">
            <button type="submit" class="px-4 py-2 bg-primary-600 text-white rounded-r-lg text-sm hover:bg-primary-700">Найти</button>
        </form>
        <div class="flex items-center gap-2">
            <?php if($productsData['source'] ?? '' === 'live'): ?>
                <span class="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">Live</span>
            <?php elseif(($productsData['source'] ?? '') === 'db'): ?>
                <span class="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded-full">БД</span>
            <?php endif; ?>
            <a href="/admin" class="text-xs text-slate-400 hover:text-slate-600">Admin</a>
            <button type="button" id="menuToggle" class="lg:hidden p-2 rounded-lg border border-slate-200">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
        </div>
    </div>
</header>


<div id="mobileMenu" class="fixed inset-0 z-40 lg:hidden hidden">
    <div id="mobileMenuBackdrop" class="absolute inset-0 bg-black/50"></div>
    <aside class="absolute left-0 top-0 bottom-0 w-72 bg-white shadow-xl overflow-y-auto">
        <div class="p-4 border-b flex justify-between items-center">
            <span class="font-semibold">Категории</span>
            <button type="button" id="menuClose" class="p-2 rounded-lg hover:bg-slate-100">✕</button>
        </div>
        <ul class="py-2">
            <li><a href="/" class="block px-4 py-3 <?php echo e($categorySlug === '' ? 'bg-primary-50 text-primary-700' : 'text-slate-600'); ?>">Все товары</a></li>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="/?category=<?php echo e($cat['slug'] ?? ''); ?>" class="block px-4 py-3 <?php echo e(($cat['slug'] ?? '') === $categorySlug ? 'bg-primary-50 text-primary-700' : 'text-slate-600'); ?>">
                        <?php echo e($cat['title'] ?? ''); ?>

                    </a>
                    <?php if(!empty($cat['children'])): ?>
                        <?php $__currentLoopData = $cat['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/?category=<?php echo e($ch['slug'] ?? ''); ?>" class="block pl-8 py-2 text-sm <?php echo e(($ch['slug'] ?? '') === $categorySlug ? 'text-primary-600' : 'text-slate-500'); ?>">
                                <?php echo e($ch['title'] ?? ''); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </aside>
</div>

<div class="max-w-7xl mx-auto px-4 py-6 flex gap-6">
    
    <aside class="w-64 flex-shrink-0 hidden lg:block">
        <nav class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden sticky top-20 max-h-[calc(100vh-6rem)] overflow-y-auto scrollbar-thin">
            <div class="p-3 border-b border-slate-100">
                <h2 class="font-semibold text-slate-700">Категории</h2>
            </div>
            <ul class="py-2">
                <li>
                    <a href="/" class="block px-4 py-2 text-sm <?php echo e($categorySlug === '' ? 'bg-primary-50 text-primary-700 font-medium' : 'text-slate-600 hover:bg-slate-50'); ?>">Все товары</a>
                </li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="border-b border-slate-50 last:border-0">
                        <a href="/?category=<?php echo e($cat['slug'] ?? ''); ?>" class="block px-4 py-2.5 text-sm <?php echo e(($cat['slug'] ?? '') === $categorySlug ? 'bg-primary-50 text-primary-700 font-medium' : 'text-slate-600 hover:bg-slate-50'); ?>">
                            <?php echo e($cat['title'] ?? ''); ?>

                        </a>
                        <?php if(!empty($cat['children'])): ?>
                            <ul class="pl-4 pb-1">
                                <?php $__currentLoopData = array_slice($cat['children'], 0, 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="/?category=<?php echo e($ch['slug'] ?? ''); ?>" class="block py-1.5 text-xs <?php echo e(($ch['slug'] ?? '') === $categorySlug ? 'text-primary-600 font-medium' : 'text-slate-500 hover:text-slate-700'); ?>">
                                            <?php echo e($ch['title'] ?? ''); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>
    </aside>

    
    <main class="flex-1 min-w-0">
        <div class="flex items-center justify-between mb-4">
            <h1 class="text-2xl font-bold text-slate-800"><?php echo e($currentCategoryTitle); ?></h1>
            <?php if(!empty($productsData['total'])): ?>
                <span class="text-sm text-slate-500"><?php echo e(number_format($productsData['total'])); ?> товаров</span>
            <?php endif; ?>
        </div>

        <?php if(!empty($productsData['error'])): ?>
            <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 text-amber-800 text-sm mb-4">
                ⚠ Ошибка загрузки: <?php echo e($productsData['error']); ?>

            </div>
        <?php endif; ?>

        <?php if(empty($productsData['items'])): ?>
            <div class="bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-500">
                <?php if($categorySlug): ?>
                    Нет товаров в этой категории. Запустите парсинг в
                    <a href="/admin" class="text-primary-600 hover:underline">Admin Panel</a>.
                <?php else: ?>
                    Нет товаров. Выберите категорию или запустите парсинг в
                    <a href="/admin" class="text-primary-600 hover:underline">Admin Panel</a>.
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                <?php $__currentLoopData = $productsData['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $pTitle = $p['title'] ?? ('Товар ' . ($p['id'] ?? ''));
                        $pPrice = $p['price'] ?? '';
                        $pPhoto = $p['photo'] ?? ($p['photos'][0] ?? null);
                        $pId = $p['id'] ?? '';
                    ?>
                    <a href="/product/<?php echo e($pId); ?>" class="group bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md hover:border-primary-200 transition-all duration-200">
                        <div class="aspect-square bg-slate-100 overflow-hidden">
                            <?php if($pPhoto): ?>
                                <img src="<?php echo e($pPhoto); ?>" alt="<?php echo e($pTitle); ?>"
                                    class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                    loading="lazy"
                                    onerror="this.parentElement.innerHTML='<div class=\'w-full h-full flex items-center justify-center text-4xl text-slate-300\'>📦</div>'">
                            <?php else: ?>
                                <div class="w-full h-full flex items-center justify-center text-slate-400 text-4xl">📦</div>
                            <?php endif; ?>
                        </div>
                        <div class="p-3">
                            <h3 class="font-medium text-slate-800 text-sm line-clamp-2 min-h-[2.5rem] group-hover:text-primary-600"><?php echo e($pTitle); ?></h3>
                            <?php if($pPrice): ?>
                                <p class="mt-1 text-primary-600 font-semibold text-sm"><?php echo e($pPrice); ?></p>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <?php if(($productsData['total_pages'] ?? 1) > 1): ?>
                <div class="mt-8 flex flex-wrap items-center justify-center gap-2">
                    <?php if($page > 1): ?>
                        <a href="/?category=<?php echo e($categorySlug); ?>&page=<?php echo e($page - 1); ?>" class="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50">← Назад</a>
                    <?php endif; ?>
                    <?php $totalPages = $productsData['total_pages'] ?? 1; ?>
                    <?php for($i = max(1, $page - 3); $i <= min($totalPages, $page + 3); $i++): ?>
                        <a href="/?category=<?php echo e($categorySlug); ?>&page=<?php echo e($i); ?>"
                           class="px-4 py-2 rounded-lg <?php echo e($i === $page ? 'bg-primary-600 text-white' : 'border border-slate-200 text-slate-600 hover:bg-slate-50'); ?>">
                            <?php echo e($i); ?>

                        </a>
                    <?php endfor; ?>
                    <?php if($page < $totalPages): ?>
                        <a href="/?category=<?php echo e($categorySlug); ?>&page=<?php echo e($page + 1); ?>" class="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50">Вперёд →</a>
                    <?php endif; ?>
                </div>
                <p class="mt-2 text-center text-sm text-slate-500">Страница <?php echo e($page); ?> из <?php echo e($totalPages); ?> (всего <?php echo e(number_format($productsData['total'])); ?> товаров)</p>
            <?php endif; ?>
        <?php endif; ?>
    </main>
</div>

<footer class="border-t border-slate-200 mt-12 py-6 text-center text-sm text-slate-500">
    Данные с агрегатора <a href="https://sadovodbaza.ru" class="text-primary-600 hover:underline" target="_blank" rel="noopener">sadovodbaza.ru</a>.
    | <a href="/admin" class="hover:text-primary-600">Admin Panel</a>
    | <a href="/api/v1/public/menu" class="hover:text-primary-600">API</a>
</footer>

<script>
    document.getElementById('menuToggle')?.addEventListener('click', () => document.getElementById('mobileMenu').classList.remove('hidden'));
    document.getElementById('menuClose')?.addEventListener('click', () => document.getElementById('mobileMenu').classList.add('hidden'));
    document.getElementById('mobileMenuBackdrop')?.addEventListener('click', () => document.getElementById('mobileMenu').classList.add('hidden'));
</script>
</body>
</html>
<?php /**PATH C:\OSPanel\domains\sadavod-laravel\resources\views/catalog/index.blade.php ENDPATH**/ ?>